# Skill Drafts Layout

This folder keeps editable skill source folders, page-specific brand kits, and upload-ready ZIP packages.

## Current Layout

```text
skill-drafts/
  shared/
    drive-reference-search-guidelines/
    facebook-fanpage-content-guidelines/
    fanpage-content-creator-guidelines/
    fanpage-design-guidelines/
    fanpage-grounded-content-guidelines/
    fanpage-internet-research-guidelines/
    fanpage-lead-orchestration-guidelines/
    gpt-image-2-pro-max/
    packages/

  pages/
    pizza-hips/
      skills/
        brand-pizza-hips-guidelines/
        pizza-hips-franchise-knowledge/
      packages/

    si-pizza-nuong-lua-hips/
      skills/
        brand-si-pizza-nuong-lua-hips-guidelines/
        si-pizza-nuong-lua-hips-product-business-knowledge/
        si-pizza-nuong-lua-hips-visual-content-profile/
      packages/

    lpc-france/
      skills/
        brand-lpc-france-guidelines/
        lpc-france-outsourcing-knowledge/
      packages/

    ubot-vietnam/
      skills/
        brand-ubot-vietnam-guidelines/
        ubot-vietnam-floor-system-knowledge/
      packages/

    duculaba/
      skills/
        brand-duculaba-guidelines/
        duculaba-baking-supply-knowledge/
      packages/

    baketek/
      skills/
        brand-baketek-guidelines/
        baketek-recipe-culture-knowledge/
      packages/

    ki-su-san-phang/
      skills/
        brand-ki-su-san-phang-guidelines/
        ki-su-san-phang-structural-knowledge/
        Be_Vietnam_Pro.zip
      brand-kits/ki-su-san-phang/
      packages/
```

## What Goes Where

- `shared/*`: reusable skills for many fanpage teams.
- `shared/packages/*`: ZIP packages for shared skills.
- `pages/{page_slug}/skills/*`: page-specific skills.
- `pages/{page_slug}/brand-kits/*`: global workspace materials such as fonts, brand rules, render presets, and deterministic typography assets.
- `pages/{page_slug}/packages/*`: upload-ready page-specific ZIP packages.
- Edit source folders first, then rebuild ZIPs. Do not edit packages as source.

## Shared Skills

Use these across fanpage teams:

```text
shared/facebook-fanpage-content-guidelines/
shared/drive-reference-search-guidelines/
shared/fanpage-content-creator-guidelines/
shared/fanpage-design-guidelines/
shared/fanpage-grounded-content-guidelines/
shared/fanpage-internet-research-guidelines/
shared/fanpage-lead-orchestration-guidelines/
shared/gpt-image-2-pro-max/
```

Upload packages:

```text
shared/packages/facebook-fanpage-content-guidelines.zip
shared/packages/drive-reference-search-guidelines.zip
shared/packages/fanpage-brand-qa-claim-safety-guidelines.zip
shared/packages/fanpage-content-creator-guidelines.zip
shared/packages/fanpage-design-guidelines.zip
shared/packages/fanpage-grounded-content-guidelines.zip
shared/packages/fanpage-internet-research-guidelines.zip
shared/packages/fanpage-lead-orchestration-guidelines.zip
shared/packages/fanpage-sales-angle-guidelines.zip
shared/packages/gpt-image-2-pro-max.zip
shared/packages/gpt-image-2-pro-max.tar.gz
```

## Page Skills And Uploads

### Pizza Hip'S

Purpose:

- `brand-pizza-hips-guidelines`: Pizza Hip'S identity, tone, fixed Kiosk footer, hashtags, watermark zones, image rules, and brand typography instructions.
- `pizza-hips-franchise-knowledge`: franchise/F&B business model content, legal-risk wording, and Pizza Hip'S franchise education.

Skill uploads:

```text
pages/pizza-hips/packages/brand-pizza-hips-guidelines.zip
pages/pizza-hips/packages/pizza-hips-franchise-knowledge.zip
pages/pizza-hips/packages/pizza-hips-visual-content-profile.zip
```

Do not use a Pizza Hip'S brand-kit package for team setup.

### Sỉ Pizza nướng lửa Hip'S

Purpose:

- `brand-si-pizza-nuong-lua-hips-guidelines`: B2B page identity, wholesale-sales direction, audience, CTA, hashtag logic, and safe claim framing for the Sỉ Pizza nướng lửa Hip'S Facebook page.
- `si-pizza-nuong-lua-hips-product-business-knowledge`: product lines, process talking points, spaghetti support, B2B menu-fit logic, and small-store operations guidance.
- `si-pizza-nuong-lua-hips-visual-content-profile`: default visual route mapping for B2B product, process, and store-operations posts.

Skill uploads:

```text
pages/si-pizza-nuong-lua-hips/packages/brand-si-pizza-nuong-lua-hips-guidelines.zip
pages/si-pizza-nuong-lua-hips/packages/si-pizza-nuong-lua-hips-product-business-knowledge.zip
pages/si-pizza-nuong-lua-hips/packages/si-pizza-nuong-lua-hips-visual-content-profile.zip
```

### LPC France

Purpose:

- `brand-lpc-france-guidelines`: LPC France brand/page rules, French-first English-below format, fixed bilingual footer, French/English hashtags, B2B tone, and top-left watermark safe zone.
- `lpc-france-outsourcing-knowledge`: BIM, design support, drafting, UBoot Beton, flat slab, green construction, ESG, and French-market outsourcing lead-generation knowledge.

Skill uploads:

```text
pages/lpc-france/packages/brand-lpc-france-guidelines.zip
pages/lpc-france/packages/lpc-france-outsourcing-knowledge.zip
```

No LPC France brand kit exists yet.

### UBOT Vietnam

Purpose:

- `brand-ubot-vietnam-guidelines`: UBOT VIỆT NAM page rules, Vietnamese technical-sales tone, fixed footer, CTA, hashtag selection, top-left watermark safe zone, visual guidance, and Ubot solution lead-generation positioning.
- `ubot-vietnam-floor-system-knowledge`: Ubot/U-Bot Beton, beamless flat slabs, hollow/voided slabs, long-span floors, cost optimization, MEP coordination, project applications, green materials, and safe handling of technical/cost claims.

Skill uploads:

```text
pages/ubot-vietnam/packages/brand-ubot-vietnam-guidelines.zip
pages/ubot-vietnam/packages/ubot-vietnam-floor-system-knowledge.zip
```

No UBOT Vietnam brand kit exists yet.

### Duculaba

Purpose:

- `brand-duculaba-guidelines`: Duculaba page rules, Vietnamese sales tone, fixed footer, hashtag selection, top-left watermark safe zone, visual guidance, and baking ingredient sales positioning.
- `duculaba-baking-supply-knowledge`: baking flour, flour lines, premixes, additives, cacao, matcha, starches, ingredient applications, recipe-support limits, storage, wholesale/retail buyer advice, and safe food-content claims.

Skill uploads:

```text
pages/duculaba/packages/brand-duculaba-guidelines.zip
pages/duculaba/packages/duculaba-baking-supply-knowledge.zip
```

No Duculaba brand kit exists yet.

### BakeTek

Purpose:

- `brand-baketek-guidelines`: BakeTek page rules, Vietnamese friendly/expert recipe tone, fixed footer, hashtag selection, top-right watermark safe zone, visual guidance, detailed recipe format, and ingredient-linked sales positioning.
- `baketek-recipe-culture-knowledge`: detailed baking recipes, new cake trends, baking culture/habits, unusual cake ideas, flour, Bakers Choice, mooncake baking, additives, ingredient applications, storage, troubleshooting, and safe healthy/food claims.

Skill uploads:

```text
pages/baketek/packages/brand-baketek-guidelines.zip
pages/baketek/packages/baketek-recipe-culture-knowledge.zip
```

No BakeTek brand kit exists yet.

### Ki Su San Phang

Purpose:

- `brand-ki-su-san-phang-guidelines`: Vietnamese technical knowledge-channel rules, fixed LPC footer, hashtag selection, soft CTA, Be Vietnam Pro on-image typography guidance, and top-left watermark safe zone.
- `ki-su-san-phang-structural-knowledge`: construction standards, Vietnam comparisons, flat slabs, UBoot Beton, long-span slabs, complex structural design, green materials, ESG, and practical engineering experience.

Skill uploads:

```text
pages/ki-su-san-phang/packages/brand-ki-su-san-phang-guidelines.zip
pages/ki-su-san-phang/packages/ki-su-san-phang-structural-knowledge.zip
```

Brand kit upload:

```text
pages/ki-su-san-phang/packages/brand-kits.zip
```

Brand kit contents:

```text
pages/ki-su-san-phang/brand-kits/ki-su-san-phang/BRAND.md
pages/ki-su-san-phang/brand-kits/ki-su-san-phang/render-preset.json
pages/ki-su-san-phang/brand-kits/ki-su-san-phang/assets/fonts/BeVietnamPro-Regular.ttf
pages/ki-su-san-phang/brand-kits/ki-su-san-phang/assets/fonts/BeVietnamPro-Medium.ttf
pages/ki-su-san-phang/brand-kits/ki-su-san-phang/assets/fonts/BeVietnamPro-Bold.ttf
pages/ki-su-san-phang/brand-kits/ki-su-san-phang/assets/fonts/BeVietnamPro-ExtraBold.ttf
```

## Recommended Agent Skill Sets

### Shared Specialist Agents

Research agent:

```text
shared/packages/fanpage-internet-research-guidelines.zip
```

Content agent:

```text
shared/packages/facebook-fanpage-content-guidelines.zip
shared/packages/fanpage-content-creator-guidelines.zip
shared/packages/fanpage-grounded-content-guidelines.zip
```

Design agent:

```text
shared/packages/facebook-fanpage-content-guidelines.zip
shared/packages/fanpage-design-guidelines.zip
shared/packages/drive-reference-search-guidelines.zip
```

### Page Lead Agents

Pizza Hip'S Lead:

```text
shared/packages/fanpage-lead-orchestration-guidelines.zip
shared/packages/facebook-fanpage-content-guidelines.zip
shared/packages/fanpage-grounded-content-guidelines.zip
pages/pizza-hips/packages/brand-pizza-hips-guidelines.zip
pages/pizza-hips/packages/pizza-hips-franchise-knowledge.zip
```

LPC France Lead:

```text
shared/packages/fanpage-lead-orchestration-guidelines.zip
shared/packages/facebook-fanpage-content-guidelines.zip
shared/packages/fanpage-grounded-content-guidelines.zip
pages/lpc-france/packages/brand-lpc-france-guidelines.zip
pages/lpc-france/packages/lpc-france-outsourcing-knowledge.zip
```

UBOT Vietnam Lead:

```text
shared/packages/fanpage-lead-orchestration-guidelines.zip
shared/packages/facebook-fanpage-content-guidelines.zip
shared/packages/fanpage-grounded-content-guidelines.zip
pages/ubot-vietnam/packages/brand-ubot-vietnam-guidelines.zip
pages/ubot-vietnam/packages/ubot-vietnam-floor-system-knowledge.zip
```

Duculaba Lead:

```text
shared/packages/fanpage-lead-orchestration-guidelines.zip
shared/packages/facebook-fanpage-content-guidelines.zip
shared/packages/fanpage-grounded-content-guidelines.zip
pages/duculaba/packages/brand-duculaba-guidelines.zip
pages/duculaba/packages/duculaba-baking-supply-knowledge.zip
```

BakeTek Lead:

```text
shared/packages/fanpage-lead-orchestration-guidelines.zip
shared/packages/facebook-fanpage-content-guidelines.zip
shared/packages/fanpage-grounded-content-guidelines.zip
pages/baketek/packages/brand-baketek-guidelines.zip
pages/baketek/packages/baketek-recipe-culture-knowledge.zip
```

Ki Su San Phang Lead:

```text
shared/packages/fanpage-lead-orchestration-guidelines.zip
shared/packages/facebook-fanpage-content-guidelines.zip
shared/packages/fanpage-grounded-content-guidelines.zip
pages/ki-su-san-phang/packages/brand-ki-su-san-phang-guidelines.zip
pages/ki-su-san-phang/packages/ki-su-san-phang-structural-knowledge.zip
```

## Rebuild ZIPs After Editing Folders

Run commands from the parent directory that contains `skill-drafts`, or adjust paths if running from inside `skill-drafts`.

Shared skill example:

```powershell
tar -a -cf `
  skill-drafts\shared\packages\facebook-fanpage-content-guidelines.zip `
  -C skill-drafts\shared\facebook-fanpage-content-guidelines .
```

Page skill example:

```powershell
tar -a -cf `
  skill-drafts\pages\duculaba\packages\brand-duculaba-guidelines.zip `
  -C skill-drafts\pages\duculaba\skills\brand-duculaba-guidelines .
```

Brand kit example:

```powershell
tar -a -cf `
  skill-drafts\pages\ki-su-san-phang\packages\brand-kits.zip `
  -C skill-drafts\pages\ki-su-san-phang brand-kits
```

If running from inside `skill-drafts`, omit the leading `skill-drafts\`:

```powershell
tar -a -cf `
  pages\duculaba\packages\brand-duculaba-guidelines.zip `
  -C pages\duculaba\skills\brand-duculaba-guidelines .
```

If `tar` fails to open an existing ZIP, remove or rename the old generated package and run the same command again.

## ZIP Path Rule

ZIP entries must use Unix-style forward slashes:

```text
SKILL.md
agents/openai.yaml
assets/fonts/SVN-Bango.otf
brand-kits/ki-su-san-phang/BRAND.md
brand-kits/ki-su-san-phang/assets/fonts/BeVietnamPro-ExtraBold.ttf
```

Do not package entries with Windows backslashes:

```text
agents\openai.yaml
assets\fonts\SVN-Bango.otf
brand-kits\ki-su-san-phang\BRAND.md
```

Backslash entries caused earlier font/path bugs.

For skill ZIPs, the preferred upload format has `SKILL.md` at the ZIP root:

```text
./
./SKILL.md
./agents/openai.yaml
```

For brand-kit ZIPs, keep the `brand-kits/{page_slug}/...` folder structure:

```text
brand-kits/ki-su-san-phang/BRAND.md
brand-kits/ki-su-san-phang/render-preset.json
brand-kits/ki-su-san-phang/assets/fonts/BeVietnamPro-ExtraBold.ttf
```

## Verify ZIP Entries

Quick list:

```powershell
tar -tf skill-drafts\pages\duculaba\packages\brand-duculaba-guidelines.zip
```

Backslash check:

```powershell
$zipPath = "skill-drafts\pages\duculaba\packages\brand-duculaba-guidelines.zip"

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$zip = [System.IO.Compression.ZipFile]::OpenRead((Resolve-Path $zipPath).Path)
try {
  $zip.Entries | Select-Object FullName, Length | Format-Table -AutoSize

  $bad = @($zip.Entries | Where-Object { $_.FullName -like '*\*' })
  if ($bad.Count -eq 0) {
    "OK: no backslash entries"
  } else {
    "ERROR: ZIP contains backslash entries"
    $bad | Select-Object FullName
  }
} finally {
  $zip.Dispose()
}
```

## Validation Notes

- `quick_validate.py` from the skill-creator helper currently requires `PyYAML`. If the active Python runtime does not include `yaml`, validation fails with `ModuleNotFoundError: No module named 'yaml'`.
- When that happens, manually check:
  - `SKILL.md` exists.
  - YAML frontmatter has `name` and `description`.
  - No TODO placeholders remain.
  - `agents/openai.yaml` exists when the skill uses agent metadata.
  - ZIP entries use forward slashes.
