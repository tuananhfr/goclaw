---
name: Fanpage Visual Taste Direction
slug: fanpage-visual-taste-direction
description: Shared art-direction layer for Facebook visual work. Adds camera choice, lighting intent, texture emphasis, negative-space design, contrast rhythm, and focal drama so page visuals stay brand-safe without becoming flat or generic.
---

# Fanpage Visual Taste Direction

Use this skill together with:

- page brand guidelines
- page visual profile
- visual creative workflow
- drive reference search when real references exist

This skill is not a replacement for brand rules or route rules.
It exists to prevent image work from becoming correct-but-ugly.

## Core Principle

A Facebook image should not stop at:

- correct message
- safe watermark zone
- readable text
- brand-safe route match

It must also feel visually intentional.

The goal is:

- strong first-glance impact
- clear focal hierarchy
- believable material and lighting
- controlled negative space
- enough visual energy to feel designed, not auto-generated

## What This Skill Controls

This skill helps the Visual Creative Agent decide:

- camera angle
- crop behavior
- focal priority
- lighting character
- texture emphasis
- depth and separation
- contrast rhythm
- background energy
- negative-space shape
- realism level

## What This Skill Does Not Control

This skill does not override:

- brand font rules
- watermark safe zones
- claim safety
- exact required copy
- route-specific business constraints

Those still come from the page brand skill and page visual profile.

## Anti-Flat Rules

Do not approve an image just because it is:

- readable
- brand-colored
- uncluttered
- technically usable

Reject the visual if it feels like:

- a safe but dead poster
- a centered object on a generic background
- a template with one headline area and no visual tension
- a food shot with weak appetite cues
- a B2B explainer that looks like a PowerPoint slide
- a product visual with no texture, depth, or material realism

## Visual Taste Layers

Always define these layers before generating the final image.

### 1. Focal Drama

Choose one dominant subject.

Ask:

- what should the eye hit first?
- what detail should make the image memorable?
- what gives the frame force?

Examples:

- bubbling cheese pull
- crisp crust edge
- ingredient texture
- one strong process detail
- one decisive business-context cue

Avoid multiple weak focal points.

### 2. Camera Intention

Choose camera angle deliberately.

Use:

- top-down when layout clarity and ingredient spread matter
- 3/4 angle when height, thickness, layering, or appetite depth matter
- close crop when texture is the main selling cue
- eye-level only when human relatability or store realism matters

Do not default to the same angle for every route.

### 3. Lighting Character

Lighting should match the commercial goal.

Use:

- bright directional light for fresh, clear, practical product work
- warm controlled highlights for appetite and speed-of-service food content
- softer diffused light for trustworthy baking and ingredient realism
- crisper contrast for process, heat, or technical confidence

Avoid:

- muddy low-contrast light
- random luxury moody lighting on everyday commercial posts
- flat front light with no depth

### 4. Texture Emphasis

Decide what material cues must read clearly.

Examples:

- melted cheese
- blistered crust
- sauce gloss
- flour dust
- crumb structure
- packaging realism
- structural material edge

If texture is important, prompt for it directly.
Do not rely on the model to infer it.

### 5. Negative Space Design

Negative space is not just empty room for a watermark.

It should:

- protect readability
- balance the subject
- create shape in the layout
- feel intentional, not leftover

Good negative space has a clear location and purpose.

Bad negative space feels like:

- dead empty corners
- giant blank areas with no composition logic
- safe zones that make the frame collapse visually

### 6. Background Energy

Backgrounds should support, not compete.

Choose one of these levels:

- quiet: clean, minimal, product-first
- supportive: soft props, mild texture, subtle surface context
- active: visible motion, sparks, ingredient scatter, process atmosphere

Do not use an active background when the subject is already visually busy.
Do not use a dead plain background when the image needs appetite or motion.

### 7. Contrast Rhythm

Use contrast to organize the eye.

Balance:

- bright vs dark
- warm vs cool
- sharp vs soft
- detailed vs calm
- saturated vs restrained

The frame should have visual rhythm, not one flat exposure everywhere.

### 8. Realism Threshold

Choose how real the image needs to feel.

Use:

- high realism when trust, product authenticity, or B2B credibility matters
- moderated stylization when the route is trend-led or more social
- AI support only where it does not damage trust

If the page sells real products, do not let the final result feel synthetic, rubbery, or plastic.

## Route-Based Taste Guidance

### Product Sales Visual

Should feel:

- immediate
- appetizing or desirable
- fast to read
- commercially sharp

Prefer:

- one hero subject
- one memorable texture cue
- clean but not lifeless background
- one strong light direction

### Sales Explainer Visual

Should feel:

- informative
- commercially useful
- visually controlled
- structured without becoming slide-like

Prefer:

- one dominant subject zone
- one text support zone
- enough depth and subject realism to avoid infographic stiffness

Do not let the explanatory copy flatten the image.

### Educational Infographic

Should feel:

- organized
- credible
- easy to scan

Prefer:

- strong section contrast
- controlled icon or diagram use
- practical clarity over decoration

### News Or Insight Card

Should feel:

- topical
- editorial
- sharp

Prefer:

- decisive headline area
- one supporting visual cue
- restrained but modern contrast

### Story Or Experience Visual

Should feel:

- human
- natural
- scene-led

Prefer:

- believable context
- softer transitions
- emotional clarity without sentimentality

## Food-Specific Direction

When working on food:

- make heat, texture, and edibility visible
- show enough surface imperfection to feel real
- avoid sterile symmetry unless the route truly needs it
- use props sparingly and only when they improve appetite or context
- do not let props become the story

Good food images usually need:

- one appetite trigger
- one believable surface
- one clear light direction
- one controlled area of rest

## B2B-Specific Direction

When the page is B2B, do not confuse "practical" with "visually weak".

B2B visuals should still feel:

- decisive
- professional
- memorable

Use business relevance through:

- context cue
- product-use cue
- process cue
- scale cue

Not through boring composition.

## Prompt Construction Rule

A strong final image prompt should usually specify:

- subject
- camera angle
- framing
- lighting
- texture or material emphasis
- background energy level
- realism level
- must-avoid list
- safe zone instruction

Do not stop at:

- product name
- route
- color
- no text

That is not enough for strong visual output.

## Output Add-On For The Visual Agent

Before calling image generation, define this block:

```text
VISUAL TASTE
- focal drama:
- camera intention:
- lighting character:
- texture emphasis:
- background energy:
- negative space shape:
- realism threshold:
```

## Final Rule

Brand-safe is not enough.
A good visual should feel deliberate, appetizing or convincing, and hard to mistake for a weak generic AI poster.
